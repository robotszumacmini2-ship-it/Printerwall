'use strict';
/*
 * AI print-failure watch.
 *
 * Every AI_INTERVAL_SEC seconds, for each printer that is printing, one camera frame is sent to a
 * cheap, fast Claude model (screening). If it sees something, a stronger model takes a second look.
 * Only serious failures can trigger an automatic pause/stop, and only after a further confirmation
 * on a fresh frame. Cosmetic problems (stringing, warping, ...) only raise an alert.
 *
 * Needs an API key in ANTHROPIC_API_KEY. Frames are sent to the Anthropic API.
 */
const fs = require('fs');
const path = require('path');

const API_KEY = process.env.ANTHROPIC_API_KEY || '';
const API_URL = (process.env.ANTHROPIC_BASE_URL || 'https://api.anthropic.com') + '/v1/messages';
const SCREEN_MODEL = process.env.AI_SCREEN_MODEL || 'claude-haiku-4-5-20251001';
const CONFIRM_MODEL = process.env.AI_CONFIRM_MODEL || 'claude-sonnet-5';
const INTERVAL_MS = Math.max(5, Number(process.env.AI_INTERVAL_SEC || 60)) * 1000;
const CONFIRM_GAP_MS = Math.max(1, Number(process.env.AI_CONFIRM_GAP_SEC || 15)) * 1000;
const MIN_CONF = Number(process.env.AI_MIN_CONFIDENCE || 0.7);
const SETTINGS_FILE = process.env.AI_SETTINGS_FILE || path.join(__dirname, 'ai-settings.json');
const MODES = ['off', 'alert', 'pause', 'stop'];

// What the AI may report. Only "critical" types can trigger an automatic pause or stop.
const TYPES = {
  spaghetti:          { critical: true,  label: 'Spaghetti (tangled filament, the print has come apart)' },
  detached:           { critical: true,  label: 'The print has come off the bed or is moving around' },
  nozzle_blob:        { critical: true,  label: 'A blob of plastic is building up around the nozzle' },
  printing_in_air:    { critical: true,  label: 'The nozzle is printing in mid-air with nothing beneath it' },
  no_extrusion:       { critical: true,  label: 'The nozzle is moving but nothing is being printed' },
  collapse:           { critical: true,  label: 'The print has collapsed or fallen over' },
  severe_layer_shift: { critical: true,  label: 'Severe layer shift, the upper part is clearly offset' },
  warping:            { critical: false, label: 'Corners or edges are lifting off the bed' },
  layer_separation:   { critical: false, label: 'Layers are splitting or cracking apart' },
  inconsistent_extrusion: { critical: false, label: 'Gaps, thin or missing lines, uneven extrusion' },
  messy_overhang:     { critical: false, label: 'Rough, messy surface on overhangs (support missing)' },
  melted_detail:      { critical: false, label: 'Pointed tips or fine details look melted' },
  stringing:          { critical: false, label: 'Thin strings between parts of the print' },
  layer_shift:        { critical: false, label: 'Small layer shift' },
};

const SYSTEM = `You are a quality inspector for an FDM 3D printer (Bambu Lab P1S). You get one frame from the camera inside the printer plus the printer's progress. Decide whether a print failure or defect is clearly visible.

Report only what you can clearly see. Do not guess. The camera has low resolution and the lighting can be poor. If the print or nozzle is not visible, or the image is too dark or blocked, set "visible" to false and report nothing.

These are normal and must NOT be reported: the purge line, wipe or prime tower, brim, skirt, support structures, thin first layers, the toolhead, cables, the fan, the heated bed, motion blur, and an empty plate.

Issue types you may report:
${Object.entries(TYPES).map(([k, v]) => `- ${k}: ${v.label}`).join('\n')}

Answer with JSON only and no other text:
{"visible": true or false, "issues": [{"type": "<one of the types above>", "confidence": <0 to 1>, "note": "<what you see, max 15 words>"}]}
Use an empty "issues" array when everything looks fine. A false alarm costs the user a print, so only report an issue when you are confident.`;

let printers, state, cams, actions;
const A = [];       // per printer: { mode, lastCheckAt, lastResult, note, calls, alert, alertFrame, busy }

function loadModes(n) {
  let saved = {};
  try { saved = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')); } catch (_) { /* first run */ }
  const fallback = MODES.includes(process.env.AI_DEFAULT_MODE) ? process.env.AI_DEFAULT_MODE : 'alert';
  return Array.from({ length: n }, (_, i) => (MODES.includes(saved[i]) ? saved[i] : fallback));
}
function saveModes() {
  try { fs.writeFileSync(SETTINGS_FILE, JSON.stringify(A.map((a) => a.mode))); } catch (_) { /* not fatal */ }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function context(d) {
  const state = d.gcode_state || 'unknown';
  if (state !== 'RUNNING') return `Printer state: ${state.toLowerCase()}.`;
  return `Printer state: printing, layer ${d.layer_num ?? '?'} of ${d.total_layer_num ?? '?'}, ${d.mc_percent ?? '?'}% done.`;
}

function parseAnswer(text) {
  const a = text.indexOf('{');
  const b = text.lastIndexOf('}');
  if (a < 0 || b < a) throw new Error('The AI answer was not JSON');
  const j = JSON.parse(text.slice(a, b + 1));
  const issues = (Array.isArray(j.issues) ? j.issues : [])
    .filter((x) => x && TYPES[x.type])
    .map((x) => ({
      type: x.type, critical: TYPES[x.type].critical, label: TYPES[x.type].label,
      confidence: Math.max(0, Math.min(1, Number(x.confidence) || 0)), note: String(x.note || '').slice(0, 160),
    }));
  return { visible: j.visible !== false, issues };
}

async function analyse(i, model, frame, ctx) {
  A[i].calls++;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 30000);
  try {
    const r = await fetch(API_URL, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model, max_tokens: 400, system: SYSTEM,
        messages: [{ role: 'user', content: [
          { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: frame.toString('base64') } },
          { type: 'text', text: ctx },
        ] }],
      }),
      signal: ctrl.signal,
    });
    if (!r.ok) {
      const err = new Error(r.status === 401 || r.status === 403 ? 'The API key was rejected' : `API error ${r.status}`);
      err.status = r.status;
      throw err;
    }
    const j = await r.json();
    return parseAnswer((j.content || []).filter((b) => b.type === 'text').map((b) => b.text).join(''));
  } finally {
    clearTimeout(timer);
  }
}

function raise(i, issue, frame, action) {
  const a = A[i];
  if (a.alert && a.alert.type === issue.type && action === 'none') return; // already reported
  a.alert = {
    at: Date.now(), type: issue.type, label: issue.label, critical: issue.critical,
    confidence: issue.confidence, note: issue.note, action,
  };
  a.alertFrame = frame;
  console.warn(`[${printers[i].name}] AI watch: ${issue.type} (${Math.round(issue.confidence * 100)}%) - ${issue.note} - action: ${action}`);
}

const isRunning = (i) => state[i].connected && state[i].data.gcode_state === 'RUNNING';

async function tick(i) {
  const a = A[i];
  if (a.mode === 'off' || !API_KEY) return;
  const d = state[i].data;
  if (!isRunning(i) || (d.layer_num ?? 0) < 1) { a.lastResult = 'idle'; a.note = ''; return; }
  // The last layer and the end-of-print G-code (cool-down, sweeping the part off) look like a failure but are not
  if (d.total_layer_num && d.layer_num >= d.total_layer_num) { a.lastResult = 'idle'; a.note = 'Print is finishing.'; return; }
  if (a.alert && a.alert.critical && a.mode === 'alert') return; // already alerted, wait for a dismiss

  const ctx = context(state[i].data);
  const frame = await cams[i].grab();
  if (!frame) throw new Error('No picture from the camera');

  // Stage 1: quick screening with the small model
  const r1 = await analyse(i, SCREEN_MODEL, frame, ctx);
  a.lastCheckAt = Date.now();
  if (!r1.visible) { a.lastResult = 'unclear'; a.note = ''; return; }
  if (!r1.issues.some((x) => x.confidence >= 0.5)) { a.lastResult = 'ok'; a.note = ''; return; }

  // Stage 2: the stronger model takes a second look at the same frame
  const r2 = await analyse(i, CONFIRM_MODEL, frame, ctx);
  const seen = r2.issues.filter((x) => x.confidence >= MIN_CONF).sort((x, y) => (y.critical - x.critical) || (y.confidence - x.confidence));
  if (!seen.length) { a.lastResult = 'ok'; a.note = 'A first look was suspicious, a second look found nothing.'; return; }
  const top = seen[0];

  if (!top.critical || a.mode === 'alert') {
    raise(i, top, frame, 'none');
    a.lastResult = 'issue'; a.note = top.label;
    return;
  }

  // Stage 3: automatic action only after the same kind of failure shows on a fresh frame
  await sleep(CONFIRM_GAP_MS);
  if (!isRunning(i)) return;
  const frame2 = await cams[i].grab();
  if (!frame2) throw new Error('No picture from the camera');
  const r3 = await analyse(i, CONFIRM_MODEL, frame2, context(state[i].data));
  const again = r3.issues.filter((x) => x.critical && x.confidence >= MIN_CONF).sort((x, y) => y.confidence - x.confidence);
  if (!again.length) {
    a.lastResult = 'ok'; a.note = 'A failure looked possible but was not confirmed on a second picture.';
    raise(i, top, frame, 'none'); // still tell the user, but do not touch the print
    a.alert.note = `${top.note} (not confirmed on a second picture, print left running)`;
    return;
  }
  const done = a.mode === 'stop' ? actions.stop(i) : actions.pause(i);
  raise(i, again[0], frame2, done ? (a.mode === 'stop' ? 'stopped' : 'paused') : 'failed');
  a.lastResult = 'issue'; a.note = again[0].label;
}

async function loop(i) {
  const a = A[i];
  let wait = INTERVAL_MS;
  try {
    await tick(i);
  } catch (e) {
    a.lastResult = 'error';
    a.note = e.name === 'AbortError' ? 'The AI took too long to answer' : e.message;
    a.lastCheckAt = Date.now();
    console.error(`[${printers[i].name}] AI watch: ${a.note}`);
    if (e.status === 401 || e.status === 403 || e.status === 429) wait = INTERVAL_MS * 3; // back off
  }
  setTimeout(() => loop(i), wait);
}

function start(opts) {
  ({ printers, state, cams, actions } = opts);
  const modes = loadModes(printers.length);
  printers.forEach((_, i) => A.push({ mode: modes[i], lastCheckAt: 0, lastResult: 'idle', note: '', calls: 0, alert: null, alertFrame: null }));
  if (!API_KEY) {
    console.log('AI watch is off: set ANTHROPIC_API_KEY to turn it on.');
    return;
  }
  console.log(`AI watch on (${SCREEN_MODEL} screens every ${INTERVAL_MS / 1000}s, ${CONFIRM_MODEL} confirms). Modes: ${A.map((a) => a.mode).join(', ')}`);
  printers.forEach((_, i) => setTimeout(() => loop(i), 2000 + (i * INTERVAL_MS) / printers.length)); // stagger the printers
}

function status(i) {
  const a = A[i];
  if (!a) return null;
  return {
    keyPresent: !!API_KEY,
    mode: a.mode,
    lastResult: a.lastResult,
    note: a.note,
    ageSec: a.lastCheckAt ? Math.round((Date.now() - a.lastCheckAt) / 1000) : null,
    calls: a.calls,
    alert: a.alert && { ...a.alert, hasFrame: !!a.alertFrame },
  };
}

function setMode(i, mode) {
  if (!A[i] || !MODES.includes(mode)) return false;
  A[i].mode = mode;
  saveModes();
  return true;
}

function dismiss(i) {
  if (!A[i]) return false;
  A[i].alert = null;
  A[i].alertFrame = null;
  return true;
}

const alertFrame = (i) => (A[i] && A[i].alertFrame) || null;

// One-off check for testing (never acts on the print)
async function checkNow(i) {
  if (!API_KEY) throw new Error('No ANTHROPIC_API_KEY is set');
  const frame = await cams[i].grab();
  if (!frame) throw new Error('No picture from the camera');
  return analyse(i, CONFIRM_MODEL, frame, context(state[i].data));
}

module.exports = { start, status, setMode, dismiss, alertFrame, checkNow, MODES };
