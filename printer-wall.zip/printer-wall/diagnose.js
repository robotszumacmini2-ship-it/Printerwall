'use strict';
// Usage (from the printer-wall folder):  node diagnose.js <printer-ip> <access-code> [serial]
const tls = require('tls');
const mqtt = require('mqtt');

const [ip, code, givenSerial] = process.argv.slice(2);
if (!ip || !code) {
  console.log('Usage: node diagnose.js <printer-ip> <access-code> [serial]');
  process.exit(1);
}
const out = (m) => console.log(m);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const done = (v) => { out('\nResult: ' + v); process.exit(0); };

out(`Step 1 - TLS handshake with ${ip}:8883`);
const sock = tls.connect({ host: ip, port: 8883, rejectUnauthorized: false });
sock.setTimeout(8000);
sock.on('secureConnect', () => {
  const c = sock.getPeerCertificate();
  const cn = (c.subject && c.subject.CN) || '';
  out(`  OK (${sock.getProtocol()}, certificate issued to ${cn || '?'})`);
  sock.destroy();
  let serial = givenSerial;
  if (/^[0-9A-Za-z]{10,20}$/.test(cn)) {
    if (givenSerial && givenSerial !== cn) out(`  note: you gave serial ${givenSerial}, but the printer's certificate says ${cn}. Using ${cn}.`);
    serial = cn;
  }
  if (!serial) done('Could not find the serial number. Pass it as the third argument.');
  step2(serial);
});
sock.on('timeout', () => done('FAILED at step 1. The port is open but the TLS handshake never completes, so the printer is not accepting local MQTT connections.'));
sock.on('error', (e) => done(`FAILED at step 1. ${e.code || ''} ${e.message}`));

async function step2(serial) {
  out('Step 2 - MQTT login (user bblp, your access code)');
  const c = mqtt.connect(`mqtts://${ip}:8883`, {
    username: 'bblp', password: code, rejectUnauthorized: false,
    clientId: 'diag_' + Math.random().toString(16).slice(2, 8),
    reconnectPeriod: 0, connectTimeout: 10000,
  });
  let closed = false, lastErr = '', msgs = 0;
  c.on('error', (e) => { lastErr = e.message || String(e.code || e); out('  error: ' + lastErr); });
  c.on('close', () => { closed = true; });
  c.on('message', (_t, buf) => {
    try {
      const m = JSON.parse(buf.toString());
      if (m.print) {
        if (msgs === 0) out(`  status received: state=${m.print.gcode_state ?? '?'} progress=${m.print.mc_percent ?? '?'}%`);
        msgs++;
      }
    } catch (_) { /* ignore */ }
  });

  await new Promise((res) => { c.once('connect', res); c.once('close', res); setTimeout(res, 12000); });
  if (closed || !c.connected) {
    if (/not authorized|bad user/i.test(lastErr)) done('FAILED at step 2. The printer rejected the login. Check the access code on the printer screen, and turn on LAN Only Mode / Developer mode if your firmware has it.');
    done('FAILED at step 2. The printer did not complete the MQTT login. Close Bambu Studio and phone apps that are connected to this printer and try again.');
  }
  out('  OK: logged in');

  out(`Step 3 - listening to device/${serial}/report`);
  c.subscribe(`device/${serial}/report`);
  await sleep(3000);
  if (closed) done('The printer ends the session as soon as this client listens to its status topic, even though the login worked. The usual causes are a wrong serial number or a firmware restriction on third-party access (check for a Developer mode switch in the printer network settings).');
  out('  OK: still connected after subscribing');
  await sleep(3000);
  out(`  status messages without asking: ${msgs}`);

  out('Step 4 - asking the printer for its full status');
  c.publish(`device/${serial}/request`, JSON.stringify({ pushing: { sequence_id: '0', command: 'pushall' } }));
  await sleep(6000);
  if (closed) done('The printer ends the session when a client asks for the full status. The updated server.js copes with this by only listening, but you may see less detail until the printer sends it on its own.');
  out(`  status messages in total: ${msgs}`);

  if (msgs > 0) done('MQTT works and status is arriving. Use the updated server.js and this printer should show progress.');
  done('Logged in and stayed connected, but no status arrived. Try again while the printer is printing or just woken from sleep, and check the serial number.');
}
