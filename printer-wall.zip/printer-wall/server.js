'use strict';
const express = require('express');
const mqtt = require('mqtt');
const tls = require('tls');
const net = require('net');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const FFMPEG = process.env.FFMPEG_PATH || 'ffmpeg';
const CAM_FPS = Math.max(1, Math.min(15, Number(process.env.CAM_FPS) || 6));       // frames/sec sent to the browser
const CAM_WIDTH = Math.max(320, Math.min(1920, Number(process.env.CAM_WIDTH) || 960)); // downscale width (height keeps aspect)
const CAM_QUALITY = Math.max(2, Math.min(20, Number(process.env.CAM_QUALITY) || 6));   // ffmpeg -q:v, lower = sharper and bigger
const CAM_TRANSPORT = process.env.FFMPEG_RTSP_TRANSPORT || 'tcp'; // 'udp' can cut latency further if your network copes
const CAM_HWACCEL = process.env.FFMPEG_HWACCEL || ''; // e.g. "d3d11va" (Windows), "videotoolbox" (Mac), "cuda" (Nvidia) - speeds up decode only

// Models whose camera speaks RTSPS on port 322 (needs ffmpeg on this computer). P1P/P1S/A1 use the port-6000 JPEG protocol.
const RTSP_MODELS = ['X1', 'X2D', 'P2S', 'H2D', 'H2S', 'H2C'];
const modelOf = (p) => String((p && p.model) || 'P1S').toUpperCase().replace(/[-_ ]/g, '');
function cameraMode(p) {
  if (p.camera === 'rtsp' || p.camera === 'tcp') return p.camera;
  const m = modelOf(p);
  return RTSP_MODELS.some((x) => m.startsWith(x)) ? 'rtsp' : 'tcp';
}
// Movement, Clear bed and Auto-clear are only tuned and tested for the P1S, unless a printer entry says "motion": true
const motionOk = (i) => (printers[i] && typeof printers[i].motion === 'boolean' ? printers[i].motion : modelOf(printers[i] || {}) === 'P1S');
const MOTION_MSG = 'Movement, Clear bed and Auto-clear are only set up for the P1S. This printer needs its own settings first.';
const PORT = process.env.PORT || 3000;
const CONTROL_PIN = process.env.CONTROL_PIN || ''; // optional: require a PIN for pause / resume / stop
const ACK_COMMANDS = ['pause', 'resume', 'stop', 'gcode_line'];
const printers = JSON.parse(fs.readFileSync(process.env.PRINTERS_FILE || path.join(__dirname, 'printers.json'), 'utf8'));

/* ------------------------------------------------------------------ *
 *  Status: one MQTT (TLS, port 8883) connection per printer
 * ------------------------------------------------------------------ */
const state = printers.map((p) => ({
  connected: false, updated: 0, data: {}, msgs: 0, error: null, probe: null,
  serial: p.serial, connectedAt: 0, earlyCloses: 0, pushedAt: 0, noPush: false,
  client: null, requestTopic: null, ackSeq: 0, lastAck: null, busyUntil: 0, lastSweepAt: 0,
}));

// The printer's TLS certificate is issued to its serial number, so we can read the real one from it
function certSerial(ip) {
  return new Promise((resolve) => {
    const sock = tls.connect({ host: ip, port: 8883, rejectUnauthorized: false });
    sock.setTimeout(5000);
    const finish = (v) => { sock.destroy(); resolve(v); };
    sock.on('secureConnect', () => {
      const cn = (sock.getPeerCertificate().subject || {}).CN || '';
      finish(/^[0-9A-Za-z]{10,20}$/.test(cn) ? cn : null);
    });
    sock.on('timeout', () => finish(null));
    sock.on('error', () => finish(null));
  });
}

async function startMqtt(p, i) {
  const st = state[i];
  const cn = await certSerial(p.ip);
  if (cn) {
    if (cn !== p.serial) console.warn(`[${p.name}] printers.json has serial "${p.serial}" but the printer says "${cn}". Using "${cn}".`);
    st.serial = cn;
  }
  const reportTopic = `device/${st.serial}/report`;
  const requestTopic = `device/${st.serial}/request`;

  const client = mqtt.connect(`mqtts://${p.ip}:8883`, {
    username: 'bblp',
    password: p.accessCode,
    rejectUnauthorized: false, // printers use a self-signed certificate
    clientId: `wall_${i}_${Math.random().toString(16).slice(2, 8)}`,
    reconnectPeriod: 5000,
    connectTimeout: 10000,
  });
  st.client = client;
  st.requestTopic = requestTopic;
  const pushAll = () => {
    st.pushedAt = Date.now();
    client.publish(requestTopic, JSON.stringify({ pushing: { sequence_id: '0', command: 'pushall' } }));
  };

  client.on('connect', () => {
    st.connected = true;
    st.connectedAt = Date.now();
    st.error = null;
    client.subscribe(reportTopic, (err) => { if (err && client.connected) st.error = `Subscribe failed: ${err.message}`; });
    console.log(`[${p.name}] MQTT connected (serial ${st.serial})`);
    // Ask for the full status shortly after subscribing (some printers drop the session on this request)
    setTimeout(() => { if (client.connected && !st.noPush) pushAll(); }, 1500);
  });

  client.on('message', (_topic, buf) => {
    try {
      const msg = JSON.parse(buf.toString());
      if (msg.print && ACK_COMMANDS.includes(msg.print.command) && 'result' in msg.print) {
        st.ackSeq++;
        st.lastAck = { command: msg.print.command, result: msg.print.result, reason: msg.print.reason || '' };
        console.log(`[${p.name}] ${msg.print.command}: ${msg.print.result}`);
      } else if (msg.print) {
        Object.assign(st.data, msg.print); // printers send partial updates, so merge
        if (st.msgs === 0) console.log(`[${p.name}] first status received`);
        st.msgs++;
        st.updated = Date.now();
        st.pushedAt = 0;
      }
    } catch (_) { /* ignore malformed messages */ }
  });

  client.on('close', () => {
    const wasUp = st.connected;
    st.connected = false;
    if (!wasUp) return;
    if (st.pushedAt && Date.now() - st.pushedAt < 5000) {
      st.noPush = true;
      console.warn(`[${p.name}] the printer ended the session after the full-status request. Will listen without asking.`);
    } else if (Date.now() - st.connectedAt < 4000) {
      st.earlyCloses++;
    }
    st.pushedAt = 0;
  });

  client.on('error', (e) => {
    st.error = e.message || String(e.code || e);
    console.error(`[${p.name}] MQTT error: ${st.error}`);
  });

  // Refresh the full status now and then (P1 printers dislike frequent requests)
  setInterval(() => { if (client.connected && !st.noPush) pushAll(); }, 5 * 60 * 1000);
}
printers.forEach((p, i) => startMqtt(p, i));

// Quick check of the printer's MQTT port so we can say *why* status is missing
function probe(i) {
  const st = state[i];
  const s = net.connect({ host: printers[i].ip, port: 8883 });
  s.setTimeout(4000);
  s.on('connect', () => { st.probe = 'open'; s.destroy(); });
  s.on('timeout', () => { st.probe = 'timeout'; s.destroy(); });
  s.on('error', (e) => { st.probe = e.code === 'ECONNREFUSED' ? 'refused' : 'unreachable'; });
}
printers.forEach((_, i) => {
  probe(i);
  setInterval(() => { if (!state[i].connected) probe(i); }, 10000);
});

function hintFor(i) {
  const st = state[i];
  if (st.msgs === 0 && st.earlyCloses >= 2) return 'The printer ends the session right after login. Check the access code, and turn on Developer mode if your firmware has it. Run diagnose.js for details.';
  if (!st.connected) {
    const e = st.error || '';
    if (/not authorized|bad user/i.test(e)) return 'The printer rejected the login. Check the access code, and turn on LAN mode / Developer mode on the printer.';
    if (/EHOSTUNREACH|ENETUNREACH/.test(e) || st.probe === 'unreachable') return 'Printer not reachable. Check its IP address and that it is on the same network.';
    if (st.probe === 'refused' || st.probe === 'timeout' || /ECONNREFUSED|ETIMEDOUT/.test(e)) return 'The printer is not offering local status (port 8883 is closed). Turn on LAN Only Mode on the printer.';
    if (st.probe === 'open') return 'Port 8883 is open but the printer ends the session. Check the access code, and turn on Developer mode if your firmware has it.';
    return e ? `Cannot connect: ${e}` : 'Connecting to the printer...';
  }
  if (st.msgs === 0) return 'Connected. Waiting for the printer to send its status...';
  return null;
}

/* ------------------------------------------------------------------ *
 *  Camera: P1-series printers send JPEG frames over TLS on port 6000.
 *  One upstream connection per printer is shared by every browser tab.
 * ------------------------------------------------------------------ */
class Camera {
  constructor(p) {
    this.p = p;
    this.clients = new Set();
    this.sock = null;
    this.retry = null;
    this.watchdog = null;
    this.last = null;
    this.lastAt = 0;
    this.frameAt = 0;
    this.grabbers = 0;
    this.mode = cameraMode(p);
    this.error = '';
  }

  add(res) {
    this.clients.add(res);
    if (this.last && Date.now() - this.lastAt < 5000) this.send(res, this.last); // instant first picture
    this.start();
  }

  remove(res) {
    this.clients.delete(res);
    if (!this.clients.size) {
      setTimeout(() => { if (!this.clients.size && !this.grabbers) this.stop(); }, 5000);
    }
  }

  start() {
    if (!this.watchdog) {
      this.watchdog = setInterval(() => {
        if (this.sock && Date.now() - this.lastAt > 15000) this.sock.destroy(); // stalled: reconnect
      }, 5000);
    }
    if (!this.sock && !this.retry) this.connect();
  }

  stop() {
    clearTimeout(this.retry); this.retry = null;
    clearInterval(this.watchdog); this.watchdog = null;
    if (this.sock) this.sock.destroy();
  }

  connect() {
    return this.mode === 'rtsp' ? this.connectRtsp() : this.connectTcp();
  }

  // X1 / P2S / H2 series: RTSPS on port 322, converted to a JPEG stream by ffmpeg.
  // Tuned to stay live with many printers streaming at once: a modest resolution and frame
  // rate, and ffmpeg flags that skip buffering rather than smoothing it (smoothing = lag here).
  connectRtsp() {
    const { ip, accessCode, name } = this.p;
    const url = `rtsps://bblp:${encodeURIComponent(accessCode)}@${ip}:322/streaming/live/1`;
    const input = process.env.FFMPEG_INPUT_ARGS
      ? process.env.FFMPEG_INPUT_ARGS.split(' ')
      : ['-rtsp_transport', CAM_TRANSPORT, '-probesize', '32', '-analyzeduration', '0', '-i', url];
    const args = [
      '-hide_banner', '-loglevel', 'error', '-nostdin',
      '-fflags', 'nobuffer+discardcorrupt', '-flags', 'low_delay', '-max_delay', '500000',
      ...(CAM_HWACCEL ? ['-hwaccel', CAM_HWACCEL] : []),
      ...input,
      '-an', '-vf', `fps=${CAM_FPS},scale=${CAM_WIDTH}:-2`, '-q:v', String(CAM_QUALITY),
      '-f', 'image2pipe', '-c:v', 'mjpeg', '-flush_packets', '1', 'pipe:1',
    ];
    const proc = spawn(FFMPEG, args, { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
    const handle = { destroy: () => { try { proc.kill(); } catch (_) { /* already gone */ } } };
    this.sock = handle;
    this.lastAt = Date.now();

    let finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      if (this.sock === handle) this.sock = null;
      if (this.clients.size || this.grabbers) {
        this.retry = setTimeout(() => { this.retry = null; if ((this.clients.size || this.grabbers) && !this.sock) this.connect(); }, 3000);
      }
    };
    proc.on('error', (e) => {
      this.error = e.code === 'ENOENT'
        ? 'ffmpeg was not found on this computer. Install ffmpeg (see the setup steps) or set FFMPEG_PATH.'
        : `ffmpeg error: ${e.message}`;
      console.error(`[${name}] camera: ${this.error}`);
      finish();
    });
    proc.on('close', finish);
    proc.stderr.on('data', (d) => {
      const text = d.toString().trim();
      if (!text) return;
      if (/401|unauthori[sz]ed/i.test(text)) this.error = 'The printer rejected the access code for the camera.';
      else if (/refused|timed out|no route|unreachable|Connection to/i.test(text)) this.error = 'The camera did not answer on port 322. Turn on LAN Mode Liveview on the printer, then restart it.';
      else this.error = `Camera: ${text.split('\n').pop().slice(0, 160)}`;
      console.error(`[${name}] ffmpeg: ${text.slice(0, 200)}`);
    });

    // ffmpeg writes JPEGs back to back on stdout; split them at the start (FFD8) and end (FFD9) markers
    const SOI = Buffer.from([0xff, 0xd8]);
    const EOI = Buffer.from([0xff, 0xd9]);
    let buf = Buffer.alloc(0);
    proc.stdout.on('data', (chunk) => {
      buf = Buffer.concat([buf, chunk]);
      for (;;) {
        const a = buf.indexOf(SOI);
        if (a < 0) { buf = Buffer.alloc(0); return; }
        const b = buf.indexOf(EOI, a + 2);
        if (b < 0) { if (a > 0) buf = buf.subarray(a); break; }
        this.onFrame(buf.subarray(a, b + 2));
        buf = buf.subarray(b + 2);
      }
      if (buf.length > 4 * 1024 * 1024) buf = Buffer.alloc(0); // drop a run with no valid frame boundary
    });
  }

  status() {
    return { mode: this.mode, error: this.error, frameAgoSec: this.frameAt ? Math.round((Date.now() - this.frameAt) / 1000) : null };
  }

  // P1P / P1S / A1: proprietary JPEG stream over TLS on port 6000
  connectTcp() {
    const { ip, accessCode, name } = this.p;
    const sock = tls.connect({ host: ip, port: 6000, rejectUnauthorized: false });
    this.sock = sock;
    this.lastAt = Date.now();

    sock.on('secureConnect', () => {
      // 80-byte auth packet: 0x40, 0x3000, 0, 0, username[32], access code[32]
      const auth = Buffer.alloc(80);
      auth.writeUInt32LE(0x40, 0);
      auth.writeUInt32LE(0x3000, 4);
      auth.write('bblp', 16, 'ascii');
      auth.write(accessCode, 48, 'ascii');
      sock.write(auth);
    });

    // Each frame = 16-byte header (first 4 bytes: JPEG size, little-endian) + JPEG data
    let buf = Buffer.alloc(0);
    let need = -1;
    sock.on('data', (chunk) => {
      buf = Buffer.concat([buf, chunk]);
      for (;;) {
        if (need < 0) {
          if (buf.length < 16) return;
          need = buf.readUInt32LE(0);
          buf = buf.subarray(16);
          if (need > 8 * 1024 * 1024) { sock.destroy(); return; }
        }
        if (buf.length < need) return;
        const frame = buf.subarray(0, need);
        buf = buf.subarray(need);
        need = -1;
        if (frame[0] === 0xff && frame[1] === 0xd8) this.onFrame(frame);
      }
    });

    sock.on('error', (e) => {
      this.error = /ECONNREFUSED|ETIMEDOUT|EHOSTUNREACH/.test(e.code || e.message)
        ? 'The camera did not answer. Turn on LAN Mode Liveview on the printer, and check its IP address.'
        : `Camera error: ${e.message}`;
      console.error(`[${name}] camera error: ${e.message}`);
    });
    sock.on('close', () => {
      this.sock = null;
      if (this.clients.size || this.grabbers) {
        this.retry = setTimeout(() => { this.retry = null; if ((this.clients.size || this.grabbers) && !this.sock) this.connect(); }, 3000);
      }
    });
  }

  // One fresh picture for the AI watch (opens the camera connection if nobody is watching)
  async grab(timeoutMs = 12000) {
    this.grabbers++;
    const since = Date.now();
    try {
      this.start();
      while (Date.now() - since < timeoutMs) {
        if (this.last && this.frameAt >= since) return this.last;
        await new Promise((r) => setTimeout(r, 150));
      }
      return null;
    } finally {
      this.grabbers--;
      if (!this.clients.size && !this.grabbers) {
        setTimeout(() => { if (!this.clients.size && !this.grabbers) this.stop(); }, 5000);
      }
    }
  }

  onFrame(frame) {
    this.last = Buffer.from(frame);
    this.lastAt = Date.now();
    this.frameAt = this.lastAt;
    this.error = '';
    for (const res of this.clients) this.send(res, this.last);
  }

  send(res, frame) {
    if (res.writableNeedDrain) return; // slow client: drop this frame
    res.write(`--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ${frame.length}\r\n\r\n`);
    res.write(frame);
    res.write('\r\n');
  }
}

const cams = printers.map((p) => new Camera(p));

/* ------------------------------------------------------------------ *
 *  AI watch: looks at the camera pictures and can pause or stop a failing print
 * ------------------------------------------------------------------ */
function sendPrintCommand(i, action, allowedStates) {
  const st = state[i];
  if (!st || !st.client || !st.client.connected) return false;
  if (!allowedStates.includes(st.data.gcode_state)) return false;
  st.client.publish(st.requestTopic, JSON.stringify({ print: { sequence_id: String(Date.now() % 100000), command: action, param: '' } }));
  console.warn(`[${printers[i].name}] ${action} sent by the AI watch`);
  return true;
}
const detector = require('./detector');
detector.start({
  printers, state, cams,
  actions: {
    stop: (i) => sendPrintCommand(i, 'stop', ['RUNNING', 'PAUSE', 'PREPARE']),
    pause: (i) => sendPrintCommand(i, 'pause', ['RUNNING']),
  },
});

/* ------------------------------------------------------------------ *
 *  Web server
 * ------------------------------------------------------------------ */
const app = express();
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/status', (_req, res) => {
  res.json(printers.map((p, i) => {
    const d = state[i].data;
    return {
      id: i,
      name: p.name,
      online: state[i].connected && state[i].updated > 0,
      hint: state[i].connected && state[i].updated > 0 ? null : hintFor(i),
      state: d.gcode_state ?? null,        // IDLE, RUNNING, PAUSE, FINISH, FAILED, PREPARE
      percent: d.mc_percent ?? null,
      remainingMin: d.mc_remaining_time ?? null,
      layer: d.layer_num ?? null,
      totalLayers: d.total_layer_num ?? null,
      file: d.subtask_name || d.gcode_file || null,
      nozzle: d.nozzle_temper ?? null,
      nozzleTarget: d.nozzle_target_temper ?? null,
      bed: d.bed_temper ?? null,
      bedTarget: d.bed_target_temper ?? null,
      ackSeq: state[i].ackSeq,
      ejectBusySec: Math.max(0, Math.ceil((state[i].busyUntil - Date.now()) / 1000)),
      ejectTested: ejectTested.includes(i),
      auto: autoStatus(i),
      model: modelOf(printers[i]),
      motion: motionOk(i),
      camera: cams[i].status(),
      lastAck: state[i].lastAck,
      ai: detector.status(i),
    };
  }));
});

app.get('/api/config', (_req, res) => res.json({ pinRequired: !!CONTROL_PIN }));

// Which printer states each command is allowed in
const STATE_WORDS = { RUNNING: 'printing', PAUSE: 'paused', PREPARE: 'preparing', IDLE: 'idle', FINISH: 'finished', FAILED: 'in a failed state' };
const ALLOWED = { pause: ['RUNNING'], resume: ['PAUSE'], stop: ['RUNNING', 'PAUSE', 'PREPARE'] };

// The custom header blocks other websites from firing these requests (browsers would need a CORS preflight)
function guard(req, res, next) {
  if (req.get('x-requested-with') !== 'printer-wall') return res.status(403).json({ error: 'Forbidden' });
  if (CONTROL_PIN && req.get('x-pin') !== CONTROL_PIN) return res.status(401).json({ error: 'Wrong PIN' });
  next();
}

app.post('/api/control/:id/:action', guard, (req, res) => {
  const i = Number(req.params.id);
  const action = req.params.action;
  const st = state[i];
  if (!st || !ALLOWED[action]) return res.status(404).json({ error: 'Unknown printer or action' });
  if (!st.client || !st.client.connected) return res.status(503).json({ error: 'Printer is not connected.' });

  const cur = st.data.gcode_state;
  if (!ALLOWED[action].includes(cur)) {
    return res.status(409).json({ error: `Cannot ${action} while the printer is ${STATE_WORDS[cur] || 'in an unknown state'}.` });
  }
  const payload = { print: { sequence_id: String(Date.now() % 100000), command: action, param: '' } };
  st.client.publish(st.requestTopic, JSON.stringify(payload), (err) => {
    if (err) return res.status(502).json({ error: 'Could not send the command to the printer.' });
    console.log(`[${printers[i].name}] ${action} sent`);
    res.json({ ok: true, ackSeq: st.ackSeq });
  });
});

/* ---- Moving the toolhead and bed (same G-code that Bambu Studio sends) ---- */
const MOVE_STATES = ['IDLE', 'FINISH', 'FAILED']; // never move axes during a print or pause
const SPEED = { X: 3000, Y: 3000, Z: 900 };      // mm/min

const fail = (status, error) => ({ status, body: { error } });

function sendGcodeAsync(i, gcode, opts = {}) {
  return new Promise((resolve) => {
    const st = state[i];
    if (!st) return resolve(fail(404, 'Unknown printer'));
    if (!motionOk(i)) return resolve(fail(403, MOTION_MSG));
    if (!st.client || !st.client.connected) return resolve(fail(503, 'Printer is not connected.'));
    const cur = st.data.gcode_state;
    if (!MOVE_STATES.includes(cur)) {
      return resolve(fail(409, `Movement is only allowed when the printer is idle or the print has finished (it is ${STATE_WORDS[cur] || 'in an unknown state'}).`));
    }
    if (!opts.skipBusy && Date.now() < st.busyUntil) {
      return resolve(fail(409, 'The printer is busy with the bed sweep. Wait until it has finished.'));
    }
    const payload = { print: { sequence_id: String(Date.now() % 100000), command: 'gcode_line', param: gcode } };
    st.client.publish(st.requestTopic, JSON.stringify(payload), (err) => {
      if (err) return resolve(fail(502, 'Could not send the command to the printer.'));
      const extra = opts.onSent ? opts.onSent() : {};
      resolve({ status: 200, body: { ok: true, ackSeq: st.ackSeq, ...extra } });
    });
  });
}
function sendGcode(i, gcode, res, opts) {
  sendGcodeAsync(i, gcode, opts).then((r) => res.status(r.status).json(r.body));
}

app.post('/api/move/:id', guard, express.json(), (req, res) => {
  const { axis, mm } = req.body || {};
  if (!['X', 'Y', 'Z'].includes(axis) || ![-10, -1, 1, 10].includes(mm)) {
    return res.status(400).json({ error: 'Invalid move' });
  }
  const gcode = 'M211 S \nM211 X1 Y1 Z1\nM1002 push_ref_mode\nG91 \n' +
    `G1 ${axis}${mm.toFixed(1)} F${SPEED[axis]}\n` + 'M1002 pop_ref_mode\nM211 R\n';
  console.log(`[${(printers[Number(req.params.id)] || {}).name}] move ${axis} ${mm}`);
  sendGcode(Number(req.params.id), gcode, res);
});

app.post('/api/home/:id', guard, (req, res) => {
  console.log(`[${(printers[Number(req.params.id)] || {}).name}] home`);
  sendGcode(Number(req.params.id), 'G28 \n', res);
});

/* ------------------------------------------------------------------ *
 *  Bed sweep ("Clear bed"): the toolhead pushes the cooled part off the front of the plate.
 *  The geometry lives in eject.json. A test path (nozzle stays above the part) must be run
 *  once on a printer before a real push is allowed.
 * ------------------------------------------------------------------ */
const EJECT_DEFAULTS = {
  centerX: 128,            // X of the single centre-line pass (mm)
  xMin: 30, xMax: 226, pitch: 25, // whole-plate mode: one pass every `pitch` mm between xMin and xMax
  rearY: 245, frontY: 0,   // the sweep starts at the rear and ends at the front edge of the plate
  travelFeed: 6000, pushFeed: 1500, zFeed: 900, // mm/min
  homeFirst: true,         // start with G28 (set false if homing with a part on the plate is a problem)
  coolingFans: true,       // automatic clearing only: run the fans while the bed cools down
  minPartHeight: 3, maxPartHeight: 150,
};
function ejectConfigProblem(c) {
  const nums = ['centerX', 'xMin', 'xMax', 'pitch', 'rearY', 'frontY', 'travelFeed', 'pushFeed', 'zFeed', 'minPartHeight', 'maxPartHeight'];
  if (nums.some((k) => !Number.isFinite(c[k]))) return 'all values must be numbers';
  if (c.xMin < 0 || c.xMax > 256 || c.xMin >= c.xMax || c.centerX < 0 || c.centerX > 256) return 'X values must lie between 0 and 256 with xMin below xMax';
  if (c.pitch < 5) return 'pitch must be at least 5 mm';
  if (c.rearY < 100 || c.rearY > 256 || c.frontY < -5 || c.frontY > 20 || c.rearY <= c.frontY) return 'rearY must be 100-256 and frontY -5 to 20, with rearY above frontY';
  if ([c.travelFeed, c.pushFeed, c.zFeed].some((f) => f < 300 || f > 12000)) return 'feed rates must be between 300 and 12000 mm/min';
  if (typeof c.coolingFans !== 'boolean' || typeof c.homeFirst !== 'boolean') return 'homeFirst and coolingFans must be true or false';
  if (c.minPartHeight < 3 || c.maxPartHeight > 200 || c.minPartHeight > c.maxPartHeight) return 'part heights must be between 3 and 200 mm';
  return null;
}
let EJECT = { ...EJECT_DEFAULTS };
try {
  const user = JSON.parse(fs.readFileSync(process.env.EJECT_FILE || path.join(__dirname, 'eject.json'), 'utf8'));
  const merged = { ...EJECT_DEFAULTS, ...user };
  const problem = ejectConfigProblem(merged);
  if (problem) console.error(`eject.json ignored: ${problem}. Using the built-in defaults.`);
  else EJECT = merged;
} catch (_) { /* no eject.json: use the defaults */ }

const EJECT_STATE_FILE = process.env.EJECT_STATE_FILE || path.join(__dirname, 'eject-state.json');
let ejectTested = [];
try { ejectTested = JSON.parse(fs.readFileSync(EJECT_STATE_FILE, 'utf8')); } catch (_) { /* first run */ }
const saveEjectTested = () => { try { fs.writeFileSync(EJECT_STATE_FILE, JSON.stringify(ejectTested)); } catch (_) { /* not fatal */ } };

function buildSweep({ partHeight, coverage, test, fansOff }) {
  const c = EJECT;
  const n = (v) => Number(v.toFixed(1));
  const travelZ = Math.min(partHeight + 20, 200);                                  // bed lowered while travelling
  const pushZ = test ? partHeight + 15 : Math.min(Math.max(partHeight * 0.4, 2), 8); // nozzle height above the plate while sweeping
  const xs = [];
  if (coverage === 'plate') for (let x = c.xMin; x <= c.xMax + 0.01; x += c.pitch) xs.push(n(x));
  else xs.push(c.centerX);

  const lines = ['M211 S ', 'M211 X1 Y1 Z1']; // software end stops stay on, as in Bambu Studio's jog
  if (fansOff) lines.push('M106 P2 S0 ', 'M106 P3 S0 ');
  if (c.homeFirst) lines.push('G28 ');
  lines.push('G90 ', `G1 Z${n(travelZ)} F${c.zFeed}`);
  for (const x of xs) {
    lines.push(
      `G1 X${x} Y${c.rearY} F${c.travelFeed}`,
      `G1 Z${n(pushZ)} F${c.zFeed}`,
      `G1 Y${c.frontY} F${c.pushFeed}`,
      `G1 Z${n(travelZ)} F${c.zFeed}`,
    );
  }
  lines.push(`G1 X${c.centerX} Y${c.rearY} F${c.travelFeed}`, 'M400', 'M211 R');

  const perPass = (256 / c.travelFeed + (c.rearY - c.frontY) / c.pushFeed + (2 * (travelZ - pushZ)) / c.zFeed) * 60;
  const seconds = Math.ceil((c.homeFirst ? 60 : 0) + (travelZ / c.zFeed) * 60 + xs.length * perPass + 20);
  return { gcode: lines.join('\n') + '\n', seconds, pushZ: n(pushZ), travelZ: n(travelZ), passes: xs.length };
}

async function startSweep(i, { mode, coverage, partHeight, maxBed, fansOff }) {
  const st = state[i];
  if (!st) return fail(404, 'Unknown printer');
  if (!motionOk(i)) return fail(403, MOTION_MSG);
  const test = mode === 'test';
  if (!test && mode !== 'push') return fail(400, 'Invalid mode');
  if (!['center', 'plate'].includes(coverage)) return fail(400, 'Invalid coverage');
  const h = Number(partHeight);
  if (!(h >= EJECT.minPartHeight && h <= EJECT.maxPartHeight)) {
    return fail(400, `Part height must be between ${EJECT.minPartHeight} and ${EJECT.maxPartHeight} mm. Thinner parts cannot be pushed safely; use a scraper.`);
  }
  if (Date.now() < st.busyUntil) return fail(409, 'The printer is busy with a bed sweep. Wait until it has finished.');

  if (!test) {
    const d = st.data;
    const limit = Math.min(Math.max(Number(maxBed) || 30, 10), 60);
    if (d.gcode_state !== 'FINISH') return fail(409, 'Pushing the part off is only allowed after a finished print.');
    if (typeof d.bed_temper !== 'number') return fail(409, 'The bed temperature is unknown.');
    if ((d.bed_target_temper || 0) > 0) return fail(409, 'The bed heater is still on.');
    if (d.bed_temper > limit) return fail(409, `The bed is ${Math.round(d.bed_temper)}°. It must be below ${limit}° before the part is pushed.`);
    if (!ejectTested.includes(i)) return fail(409, 'Run the test path once on this printer first, and watch that the nozzle moves where you expect.');
  }

  const sweep = buildSweep({ partHeight: h, coverage, test, fansOff });
  st.busyUntil = Date.now() + 5000; // provisional lock against a double click
  console.log(`[${printers[i].name}] bed sweep (${test ? 'test path' : 'PUSH'}, ${coverage}, part ${h} mm): ${sweep.passes} pass(es), nozzle ${sweep.pushZ} mm above the plate, ~${sweep.seconds}s`);
  return sendGcodeAsync(i, sweep.gcode, {
    skipBusy: true,
    onSent: () => {
      st.busyUntil = Date.now() + sweep.seconds * 1000;
      st.lastSweepAt = Date.now();
      if (test && !ejectTested.includes(i)) { ejectTested.push(i); saveEjectTested(); }
      return { seconds: sweep.seconds, passes: sweep.passes, pushZ: sweep.pushZ };
    },
  });
}

app.post('/api/eject/:id', guard, express.json(), async (req, res) => {
  const r = await startSweep(Number(req.params.id), req.body || {});
  res.status(r.status).json(r.body);
});

/* ------------------------------------------------------------------ *
 *  Automatic clearing: after a print finishes, wait for the bed to cool, then push the part off.
 *  Only starts for a print that was seen finishing while this server was running.
 * ------------------------------------------------------------------ */
const AUTO_FILE = process.env.AUTO_FILE || path.join(__dirname, 'auto-settings.json');
const auto = printers.map(() => ({ enabled: false, partHeight: 20, coverage: 'center', maxBed: 35 }));
const autoRt = printers.map(() => ({ prev: null, armed: false, armedAt: 0, phase: 'off', msg: '', fansOn: false, doneAt: 0 }));
try {
  JSON.parse(fs.readFileSync(AUTO_FILE, 'utf8')).forEach((c, i) => {
    if (!auto[i] || !c) return;
    const h = Number(c.partHeight), t = Number(c.maxBed);
    auto[i] = {
      enabled: !!c.enabled,
      partHeight: h >= EJECT.minPartHeight && h <= EJECT.maxPartHeight ? h : 20,
      coverage: c.coverage === 'plate' ? 'plate' : 'center',
      maxBed: t >= 10 && t <= 60 ? Math.round(t) : 35,
    };
    if (auto[i].enabled) autoRt[i].phase = 'idle';
  });
} catch (_) { /* first run */ }
const saveAuto = () => { try { fs.writeFileSync(AUTO_FILE, JSON.stringify(auto)); } catch (_) { /* not fatal */ } };

function autoStatus(i) {
  const cfg = auto[i], rt = autoRt[i];
  return {
    ...cfg,
    phase: cfg.enabled ? rt.phase : 'off',
    msg: rt.msg,
    sweepSecLeft: Math.max(0, Math.ceil((state[i].busyUntil - Date.now()) / 1000)),
    doneAgoSec: rt.doneAt ? Math.round((Date.now() - rt.doneAt) / 1000) : null,
  };
}

async function autoFans(i, on) {
  const rt = autoRt[i];
  if (rt.fansOn === on) return;
  rt.fansOn = on;
  await sendGcodeAsync(i, on ? 'M106 P2 S255 \nM106 P3 S255 \n' : 'M106 P2 S0 \nM106 P3 S0 \n', { skipBusy: true });
}

let autoTicking = false;
async function autoTick() {
  if (autoTicking) return;
  autoTicking = true;
  try {
    for (let i = 0; i < printers.length; i++) {
      const st = state[i], cfg = auto[i], rt = autoRt[i], d = st.data, cur = d.gcode_state;

      if (st.connected && cur) {
        if (rt.prev === 'RUNNING' && cur === 'FINISH' && cfg.enabled) {
          rt.armed = true; rt.armedAt = Date.now(); rt.msg = ''; rt.phase = 'cooling';
          console.log(`[${printers[i].name}] auto-clear: print finished, waiting for the bed to cool below ${cfg.maxBed}°`);
        }
        rt.prev = cur;
      }
      if (!cfg.enabled) {
        if (rt.armed) rt.armed = false;
        if (rt.fansOn) await autoFans(i, false);
        rt.phase = 'off';
        continue;
      }
      const block = async (msg) => {
        rt.armed = false; rt.phase = 'blocked'; rt.msg = msg;
        console.warn(`[${printers[i].name}] auto-clear blocked: ${msg}`);
        if (rt.fansOn) await autoFans(i, false);
      };

      if (!rt.armed) {
        if (rt.phase === 'sweeping' && Date.now() >= st.busyUntil) { rt.phase = 'done'; rt.doneAt = Date.now(); }
        if (['RUNNING', 'PAUSE', 'PREPARE'].includes(cur) && rt.phase !== 'idle') { rt.phase = 'idle'; rt.msg = ''; }
        if (!rt.phase || rt.phase === 'off') rt.phase = 'idle';
        continue;
      }

      // armed: a print has just finished
      if (!st.connected) { rt.msg = 'Waiting for the printer connection'; continue; }
      if (cur !== 'FINISH') { rt.armed = false; rt.phase = 'idle'; rt.msg = ''; continue; }
      if (st.lastSweepAt > rt.armedAt) { rt.armed = false; rt.phase = 'done'; rt.doneAt = st.lastSweepAt; continue; } // swept by hand meanwhile
      if (!ejectTested.includes(i)) { await block('run the test path once on this printer first.'); continue; }
      const ai = detector.status(i);
      if (ai && ai.alert && ai.alert.critical) { await block('the AI watch reported a problem with this print. Check the plate and clear it by hand.'); continue; }
      if (d.total_layer_num && d.total_layer_num * 0.08 > cfg.partHeight) {
        await block(`this print has ${d.total_layer_num} layers, so it is probably taller than the ${cfg.partHeight} mm set for auto-clear.`);
        continue;
      }
      if (typeof d.bed_temper !== 'number') { rt.phase = 'cooling'; rt.msg = 'Waiting for the bed temperature'; continue; }
      if ((d.bed_target_temper || 0) > 0) { rt.phase = 'cooling'; rt.msg = 'The bed heater is still on'; continue; }
      if (d.bed_temper > cfg.maxBed) {
        rt.phase = 'cooling'; rt.msg = '';
        if (EJECT.coolingFans && !rt.fansOn) await autoFans(i, true);
        continue;
      }
      if (Date.now() < st.busyUntil) continue;

      rt.fansOn = false; // the sweep G-code switches the fans off itself
      const r = await startSweep(i, { mode: 'push', coverage: cfg.coverage, partHeight: cfg.partHeight, maxBed: cfg.maxBed, fansOff: true });
      rt.armed = false;
      if (r.status === 200) { rt.phase = 'sweeping'; rt.msg = ''; console.log(`[${printers[i].name}] auto-clear: sweep started`); }
      else { rt.phase = 'blocked'; rt.msg = r.body.error; console.warn(`[${printers[i].name}] auto-clear blocked: ${r.body.error}`); }
    }
  } catch (e) {
    console.error('auto-clear:', e.message);
  } finally {
    autoTicking = false;
  }
}
setInterval(autoTick, 3000);

app.post('/api/auto/:id', guard, express.json(), (req, res) => {
  const i = Number(req.params.id);
  if (!auto[i]) return res.status(404).json({ error: 'Unknown printer' });
  const b = req.body || {};
  if (b.enabled && !motionOk(i)) return res.status(403).json({ error: MOTION_MSG });
  if (b.enabled) {
    const h = Number(b.partHeight), t = Number(b.maxBed);
    if (!(h >= EJECT.minPartHeight && h <= EJECT.maxPartHeight)) return res.status(400).json({ error: `Part height must be between ${EJECT.minPartHeight} and ${EJECT.maxPartHeight} mm.` });
    if (!['center', 'plate'].includes(b.coverage)) return res.status(400).json({ error: 'Invalid coverage' });
    if (!(t >= 10 && t <= 60)) return res.status(400).json({ error: 'The bed temperature must be between 10 and 60 degrees.' });
    if (!ejectTested.includes(i)) return res.status(409).json({ error: 'Run the test path once on this printer first (Clear bed, then Test path).' });
    auto[i] = { enabled: true, partHeight: h, coverage: b.coverage, maxBed: Math.round(t) };
    autoRt[i].phase = 'idle'; autoRt[i].msg = '';
    console.log(`[${printers[i].name}] auto-clear ON: ${h} mm parts, ${b.coverage}, push below ${Math.round(t)}°`);
  } else {
    auto[i].enabled = false;
    autoRt[i].armed = false;
    console.log(`[${printers[i].name}] auto-clear OFF`);
  }
  saveAuto();
  res.json({ ok: true });
});

// AI watch settings (same guard as the other control buttons)
app.post('/api/ai/:id/mode', guard, express.json(), (req, res) => {
  const ok = detector.setMode(Number(req.params.id), (req.body || {}).mode);
  res.status(ok ? 200 : 400).json(ok ? { ok: true } : { error: 'Invalid mode' });
});
app.post('/api/ai/:id/dismiss', guard, (req, res) => {
  res.status(detector.dismiss(Number(req.params.id)) ? 200 : 404).json({ ok: true });
});
app.post('/api/ai/:id/check', guard, async (req, res) => {
  try {
    const r = await detector.checkNow(Number(req.params.id));
    res.json({ visible: r.visible, issues: r.issues.map(({ type, label, confidence, note }) => ({ type, label, confidence, note })) });
  } catch (e) {
    res.status(502).json({ error: e.message });
  }
});
app.get('/api/ai/:id/frame.jpg', (req, res) => {
  const f = detector.alertFrame(Number(req.params.id));
  if (!f) return res.sendStatus(404);
  res.set({ 'Content-Type': 'image/jpeg', 'Cache-Control': 'no-store' }).send(f);
});

app.get('/api/debug/:id', (req, res) => {
  const st = state[Number(req.params.id)];
  if (!st) return res.sendStatus(404);
  res.json({
    connected: st.connected, messages: st.msgs, error: st.error, serialUsed: st.serial, fullStatusRequestBlocked: st.noPush,
    lastUpdate: st.updated ? new Date(st.updated).toISOString() : null, raw: st.data,
  });
});

app.get('/api/cam/:id', (req, res) => {
  const cam = cams[Number(req.params.id)];
  if (!cam) return res.sendStatus(404);
  res.writeHead(200, {
    'Content-Type': 'multipart/x-mixed-replace; boundary=frame',
    'Cache-Control': 'no-store',
    Connection: 'keep-alive',
  });
  cam.add(res);
  res.on('close', () => cam.remove(res));
});

app.listen(PORT, '0.0.0.0', () => console.log(`Print wall running on http://localhost:${PORT}`));
